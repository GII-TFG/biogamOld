<?php
	class lesson{
		public $id = NULL;
		public $name = '';
	}
?>
